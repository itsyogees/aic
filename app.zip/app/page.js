"use client"
import React from 'react';
import Home from './pages/Home/page';

const page = () => {
  return (
    <div>
      <Home/>
  </div>
  )
}

export default page